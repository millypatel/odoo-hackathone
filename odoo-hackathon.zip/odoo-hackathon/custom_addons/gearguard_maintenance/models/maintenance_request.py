from odoo import models, fields, api

class GearGuardRequest(models.Model):
    _name = 'gearguard.request'
    _description = 'Maintenance Request'
    _inherit = ['mail.thread']

    name = fields.Char(default=lambda self: self.env['ir.sequence'].next_by_code('gearguard.request'))
    subject = fields.Char(required=True)

    equipment_id = fields.Many2one('gearguard.equipment', required=True)
    maintenance_team_id = fields.Many2one('gearguard.team', readonly=True)
    technician_id = fields.Many2one('res.users')

    request_type = fields.Selection([
        ('corrective', 'Corrective'),
        ('preventive', 'Preventive')
    ], default='corrective')

    scheduled_date = fields.Date()
    duration = fields.Float(string="Hours Spent")

    state = fields.Selection([
        ('new', 'New'),
        ('progress', 'In Progress'),
        ('repaired', 'Repaired'),
        ('scrap', 'Scrap')
    ], default='new', tracking=True)

    @api.onchange('equipment_id')
    def _onchange_equipment(self):
        if self.equipment_id:
            self.maintenance_team_id = self.equipment_id.maintenance_team_id
            self.technician_id = self.equipment_id.technician_id

    def action_progress(self):
        self.state = 'progress'

    def action_repaired(self):
        self.state = 'repaired'

    def action_scrap(self):
        self.state = 'scrap'
        self.equipment_id.is_scrapped = True
