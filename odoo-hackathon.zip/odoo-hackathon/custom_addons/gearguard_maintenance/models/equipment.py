from odoo import models, fields, api

class GearGuardEquipment(models.Model):
    _name = 'gearguard.equipment'
    _description = 'Equipment'

    name = fields.Char(required=True)
    serial_no = fields.Char()
    department = fields.Char()
    employee_id = fields.Many2one('res.users', string="Assigned To")

    purchase_date = fields.Date()
    warranty_expiry = fields.Date()
    location = fields.Char()

    maintenance_team_id = fields.Many2one('gearguard.team')
    technician_id = fields.Many2one('res.users')

    is_scrapped = fields.Boolean(default=False)

    maintenance_count = fields.Integer(compute='_compute_maintenance_count')

    def _compute_maintenance_count(self):
        for rec in self:
            rec.maintenance_count = self.env['gearguard.request'].search_count([
                ('equipment_id', '=', rec.id),
                ('state', '!=', 'repaired')
            ])
